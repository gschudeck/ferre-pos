# Configuración de Servicios para FerrePOS - Servidor Central

Este paquete contiene los archivos `systemd` para controlar los recursos del **servidor central unificado** de FerrePOS. Este servidor centraliza:

- API de operaciones (`api_pos`)
- Base de datos PostgreSQL
- API de reportes (`api_report`) como proceso opcional

## 📁 Estructura del paquete

```
ferrepos_systemd_config.zip
├── systemd/
│   ├── api_pos.service
│   ├── api_report.service
│   └── postgresql.service.d/
│       └── override.conf
├── README.md
```

## ⚙️ Instrucciones de instalación

1. **Copiar archivos:**

```bash
sudo cp systemd/api_pos.service /etc/systemd/system/
sudo cp systemd/api_report.service /etc/systemd/system/
sudo mkdir -p /etc/systemd/system/postgresql.service.d/
sudo cp systemd/postgresql.service.d/override.conf /etc/systemd/system/postgresql.service.d/
```

2. **Activar servicios (opcional para reportes):**

```bash
sudo systemctl daemon-reexec
sudo systemctl daemon-reload
sudo systemctl enable --now api_pos.service
sudo systemctl enable --now postgresql.service
# Activar reportes solo si se requiere:
# sudo systemctl enable --now api_report.service
```

## 🧠 Recursos asignados por servicio

| Servicio     | CPUQuota | MemoryMax | Nice | Estado     |
|--------------|----------|-----------|------|------------|
| PostgreSQL   | 40%      | 6G        | -5   | Obligatorio|
| API_POS      | 40%      | 4G        | 0    | Obligatorio|
| API_REPORT   | 20%      | 1G        | 10   | Opcional   |

## 🎯 Objetivo de configuración

- Asegurar que `api_pos` tenga prioridad alta y acceso garantizado a CPU/RAM.
- Proteger a `postgresql` como componente crítico de datos.
- Permitir uso limitado de `api_report` sin afectar operaciones.

## 📝 Notas

- Ajusta `/ruta/a/api_pos` y `/ruta/a/api_report` según la ruta real en tu servidor.
- Cambia `User=ferrepos` si usas otro usuario de sistema.
- El módulo de monitoreo Prometheus + Grafana puede ejecutarse por separado si es necesario, y no está incluido aquí.

